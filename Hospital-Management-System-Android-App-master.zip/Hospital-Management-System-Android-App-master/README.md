# Hospital Management System
### We cure, You heal
#### NOTE:Project is still in developement
![image](https://drive.google.com/uc?export=view&id=13X2e0HkY0NAf8qojfNFoqcBqQ2D5PhHk)
