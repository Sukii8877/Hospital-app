package com.example.hms;

import retrofit2.Call;
import retrofit2.http.POST;

public interface API {
}
