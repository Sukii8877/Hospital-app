package com.example.hms.HeadStaff;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.hms.R;

public class GenerateSalary extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_generate_salary);
    }
}
